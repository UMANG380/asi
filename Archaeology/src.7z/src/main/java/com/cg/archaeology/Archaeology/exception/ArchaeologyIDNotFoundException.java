package com.cg.archaeology.Archaeology.exception;

public class ArchaeologyIDNotFoundException extends Exception{

    public ArchaeologyIDNotFoundException(String message) {
        super(message);
    }
}
