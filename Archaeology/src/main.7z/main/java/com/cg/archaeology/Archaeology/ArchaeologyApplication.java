package com.cg.archaeology.Archaeology;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArchaeologyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArchaeologyApplication.class, args);
	}

}
