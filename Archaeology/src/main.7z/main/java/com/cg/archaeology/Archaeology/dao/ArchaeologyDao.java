package com.cg.archaeology.Archaeology.dao;

import com.cg.archaeology.Archaeology.model.Archaeology;

import java.util.HashMap;

public interface ArchaeologyDao {

    public HashMap<Integer, Archaeology> viewAllArchaeologies();
    public Archaeology viewArchaeologyById(int id);
    public boolean updateArchaeologyById(Archaeology archaeology, int id);
    public boolean deleteArchaeologyById(int id);
    public boolean createArchaeology(Archaeology archaeology);
}
