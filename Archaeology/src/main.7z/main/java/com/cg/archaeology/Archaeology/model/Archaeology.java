package com.cg.archaeology.Archaeology.model;

import java.util.Date;

public class Archaeology {
    int id;
    String name;
    String desc;
    String condition;
    String location;
    Date date;

    public Archaeology(int id, String name, String desc, String condition, String location, Date date) {
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.condition = condition;
        this.location = location;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date =  date;
    }

    @Override
    public String toString() {
        return "Archaeology{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", desc='" + desc + '\'' +
                ", condition='" + condition + '\'' +
                ", location='" + location + '\'' +
                ", date=" + date +
                '}';
    }
}
