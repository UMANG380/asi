package com.cg.archaeology.Archaeology.service;

import com.cg.archaeology.Archaeology.dao.ArchaeologyDao;
import com.cg.archaeology.Archaeology.dao.ArchaeologyDaoImpl;
import com.cg.archaeology.Archaeology.model.Archaeology;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.HashMap;

@Service
public class ArchaeologyServiceImpl  implements ArchaeologyService{

    ArchaeologyDao dao = new ArchaeologyDaoImpl();

    public ArchaeologyServiceImpl() throws ParseException {
    }

    @Override
    public HashMap<Integer, Archaeology> viewAllArchaeologies() {
        return dao.viewAllArchaeologies();
    }

    @Override
    public Archaeology viewArchaeologyById(int id) {
       return dao.viewArchaeologyById(id);
    }

    @Override
    public boolean updateArchaeologyById(Archaeology archaeology, int id) {
        return dao.updateArchaeologyById(archaeology,id);
    }

    @Override
    public boolean deleteArchaeologyById(int id) {
        return dao.deleteArchaeologyById(id);
    }

    @Override
    public boolean createArchaeology(Archaeology archaeology) {
        return dao.createArchaeology(archaeology);
    }
}
